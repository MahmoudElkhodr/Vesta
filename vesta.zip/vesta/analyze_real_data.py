"""
X-VESTA Attribution Analysis on Real Melbourne Charging Data
Runs attribution on CHARGED dataset scenarios and generates paper figures
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
import json

# Import your existing X-VESTA code
# Assuming you have the journal evaluation code available
from dataclasses import dataclass
from enum import Enum

# ============================================
# COPY YOUR XVESTA CLASSES HERE
# ============================================
# (Use the classes from your journal evaluation code)

class Mode(str, Enum):
    MAX_SAVINGS = "MAX_SAVINGS"
    FULL_CHARGE = "FULL_CHARGE"
    GRID_SUPPORT = "GRID_SUPPORT"
    BALANCED = "BALANCED"

class Action(str, Enum):
    CHARGE = "CHARGE"
    DISCHARGE = "DISCHARGE"
    PAUSE = "PAUSE"

@dataclass
class Attribution:
    econ: float
    auto: float
    grid: float
    batt: float

    def as_dict(self):
        return {"econ": self.econ, "auto": self.auto, "grid": self.grid, "batt": self.batt}

    def dominant_factor(self):
        return max(self.as_dict().items(), key=lambda kv: kv[1])[0]

class XvestaAttributor:
    """Simplified attribution - adapt from your journal code"""
    
    def attribute(self, scenario_dict):
        """Compute attribution weights for a scenario"""
        
        # Economic factor
        price = scenario_dict['price']
        mode = scenario_dict['mode']
        econ_raw = max(0.0, price / 0.5)
        if mode == "MAX_SAVINGS":
            econ_raw *= 2.5
        elif mode == "GRID_SUPPORT":
            econ_raw *= 1.2
        
        # Autonomy factor
        auto_raw = 0.0
        if mode == "FULL_CHARGE":
            auto_raw = 1.5
        soc_deficit = scenario_dict['soc_target'] - scenario_dict['soc_start']
        auto_raw += max(0.0, soc_deficit) * 2.0
        
        # Grid factor
        grid_raw = scenario_dict['grid_stress']
        if mode == "GRID_SUPPORT":
            grid_raw += 0.6
        
        # Battery factor
        temp = scenario_dict['temp_c']
        batt_raw = 0.0
        if temp > 35.0:
            batt_raw = (temp - 35.0) / 15.0
        
        # Normalize
        raw_vec = [econ_raw, auto_raw, grid_raw, batt_raw]
        total = sum(raw_vec)
        if total == 0.0:
            raw_vec = [0.0, 1.0, 0.0, 0.0]
            total = 1.0
        
        return Attribution(
            econ=raw_vec[0]/total,
            auto=raw_vec[1]/total,
            grid=raw_vec[2]/total,
            batt=raw_vec[3]/total
        )

# ============================================
# ANALYSIS FUNCTIONS
# ============================================

def analyze_attribution_patterns(scenarios_df, sample_size=None):
    """Run attribution on all scenarios and collect statistics"""
    
    print(f"\nAnalyzing attribution patterns...")
    
    if sample_size:
        scenarios_df = scenarios_df.sample(n=min(sample_size, len(scenarios_df)))
        print(f"  Using sample of {len(scenarios_df)} scenarios")
    else:
        print(f"  Processing all {len(scenarios_df)} scenarios")
    
    attributor = XvestaAttributor()
    results = []
    
    for idx, row in scenarios_df.iterrows():
        scenario_dict = row.to_dict()
        attr = attributor.attribute(scenario_dict)
        
        result = {
            'sid': row['sid'],
            'timestamp': row['timestamp'],
            'mode': row['mode'],
            'price': row['price'],
            'temp_c': row['temp_c'],
            'hour_of_day': row['hour_of_day'],
            'is_weekend': row['is_weekend'],
            'econ_weight': attr.econ,
            'auto_weight': attr.auto,
            'grid_weight': attr.grid,
            'batt_weight': attr.batt,
            'dominant_factor': attr.dominant_factor()
        }
        results.append(result)
    
    results_df = pd.DataFrame(results)
    print(f"  ✓ Completed attribution for {len(results_df)} scenarios")
    
    return results_df

def generate_statistics(results_df):
    """Generate statistics for the paper"""
    
    print("\n" + "="*60)
    print("ATTRIBUTION STATISTICS (Real Melbourne Data)")
    print("="*60)
    
    # Overall distribution
    print("\nOverall Factor Attribution:")
    print(f"  Economic:  {results_df['econ_weight'].mean():.3f} ± {results_df['econ_weight'].std():.3f}")
    print(f"  Autonomy:  {results_df['auto_weight'].mean():.3f} ± {results_df['auto_weight'].std():.3f}")
    print(f"  Grid:      {results_df['grid_weight'].mean():.3f} ± {results_df['grid_weight'].std():.3f}")
    print(f"  Battery:   {results_df['batt_weight'].mean():.3f} ± {results_df['batt_weight'].std():.3f}")
    
    # Dominant factors
    print("\nDominant Factor Distribution:")
    dominant_counts = results_df['dominant_factor'].value_counts()
    for factor, count in dominant_counts.items():
        pct = (count / len(results_df)) * 100
        print(f"  {factor}: {count} ({pct:.1f}%)")
    
    # By mode
    print("\nAttribution by Mode:")
    for mode in results_df['mode'].unique():
        mode_data = results_df[results_df['mode'] == mode]
        print(f"\n  {mode} (n={len(mode_data)}):")
        print(f"    Econ: {mode_data['econ_weight'].mean():.3f}")
        print(f"    Auto: {mode_data['auto_weight'].mean():.3f}")
        print(f"    Grid: {mode_data['grid_weight'].mean():.3f}")
        print(f"    Batt: {mode_data['batt_weight'].mean():.3f}")
    
    # Price correlation
    price_econ_corr = results_df['price'].corr(results_df['econ_weight'])
    print(f"\nPrice-Economic Weight Correlation: r = {price_econ_corr:.3f}")
    
    # Temperature correlation
    temp_batt_corr = results_df['temp_c'].corr(results_df['batt_weight'])
    print(f"Temperature-Battery Weight Correlation: r = {temp_batt_corr:.3f}")
    
    return {
        'mean_econ': results_df['econ_weight'].mean(),
        'mean_auto': results_df['auto_weight'].mean(),
        'mean_grid': results_df['grid_weight'].mean(),
        'mean_batt': results_df['batt_weight'].mean(),
        'dominant_counts': dominant_counts.to_dict(),
        'price_econ_corr': price_econ_corr,
        'temp_batt_corr': temp_batt_corr
    }

# ============================================
# FIGURE GENERATION
# ============================================

def create_figure_attribution_pie(results_df, output_path='fig_attribution_pie.png'):
    """Figure: Overall attribution distribution (pie chart)"""
    
    fig, ax = plt.subplots(figsize=(6, 5))
    
    # Calculate average weights
    weights = {
        'Economic': results_df['econ_weight'].mean(),
        'Autonomy': results_df['auto_weight'].mean(),
        'Grid Support': results_df['grid_weight'].mean(),
        'Battery Health': results_df['batt_weight'].mean()
    }
    
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
    
    wedges, texts, autotexts = ax.pie(
        weights.values(),
        labels=weights.keys(),
        autopct='%1.1f%%',
        colors=colors,
        startangle=90
    )
    
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
        autotext.set_fontsize(10)
    
    ax.set_title('Attribution Factor Distribution\n(Melbourne Real Data, N={})'.format(
        len(results_df)), fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  ✓ Saved {output_path}")

def create_figure_temporal_heatmap(results_df, output_path='fig_temporal_heatmap.png'):
    """Figure: Dominant factor by hour of day and day of week"""
    
    # Create hour x day matrix
    results_df['day_name'] = pd.to_datetime(results_df['timestamp']).dt.day_name()
    
    # Map dominant factors to numeric values
    factor_map = {'econ': 0, 'auto': 1, 'grid': 2, 'batt': 3}
    results_df['factor_num'] = results_df['dominant_factor'].map(factor_map)
    
    # Create pivot table (mode = most common dominant factor)
    pivot = results_df.groupby(['hour_of_day', 'day_name'])['factor_num'].agg(
        lambda x: x.mode()[0] if len(x.mode()) > 0 else 0
    ).unstack(fill_value=0)
    
    # Reorder days
    day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    pivot = pivot.reindex(columns=[d for d in day_order if d in pivot.columns])
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    cmap_colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
    from matplotlib.colors import ListedColormap
    cmap = ListedColormap(cmap_colors)
    
    im = ax.imshow(pivot.T, cmap=cmap, aspect='auto', vmin=0, vmax=3)
    
    ax.set_xticks(range(24))
    ax.set_xticklabels(range(24))
    ax.set_yticks(range(len(pivot.columns)))
    ax.set_yticklabels(pivot.columns)
    
    ax.set_xlabel('Hour of Day', fontsize=11)
    ax.set_ylabel('Day of Week', fontsize=11)
    ax.set_title('Dominant Attribution Factor by Time\n(Melbourne Real Data)', 
                 fontsize=12, fontweight='bold')
    
    # Colorbar
    cbar = plt.colorbar(im, ax=ax, ticks=[0, 1, 2, 3])
    cbar.ax.set_yticklabels(['Economic', 'Autonomy', 'Grid', 'Battery'])
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  ✓ Saved {output_path}")

def create_figure_price_correlation(results_df, output_path='fig_price_correlation.png'):
    """Figure: Price vs Economic Attribution Weight"""
    
    fig, ax = plt.subplots(figsize=(8, 5))
    
    # Scatter plot with some transparency
    ax.scatter(results_df['price'], results_df['econ_weight'], 
              alpha=0.3, s=10, c='#1f77b4')
    
    # Add trend line
    z = np.polyfit(results_df['price'], results_df['econ_weight'], 1)
    p = np.poly1d(z)
    x_line = np.linspace(results_df['price'].min(), results_df['price'].max(), 100)
    ax.plot(x_line, p(x_line), "r--", linewidth=2, label=f'Trend line')
    
    # Correlation
    corr = results_df['price'].corr(results_df['econ_weight'])
    
    ax.set_xlabel('Electricity Price ($/kWh)', fontsize=11)
    ax.set_ylabel('Economic Attribution Weight', fontsize=11)
    ax.set_title(f'Price vs Economic Attribution\n(r = {corr:.3f}, N = {len(results_df)})',
                fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.legend()
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  ✓ Saved {output_path}")

def create_figure_mode_comparison(results_df, output_path='fig_mode_comparison.png'):
    """Figure: Attribution weights by mode (box plots)"""
    
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes = axes.flatten()
    
    factors = ['econ_weight', 'auto_weight', 'grid_weight', 'batt_weight']
    titles = ['Economic Factor', 'Autonomy Factor', 'Grid Support Factor', 'Battery Health Factor']
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
    
    modes = results_df['mode'].unique()
    
    for idx, (factor, title, color) in enumerate(zip(factors, titles, colors)):
        ax = axes[idx]
        
        data_by_mode = [results_df[results_df['mode'] == mode][factor].values 
                       for mode in modes]
        
        bp = ax.boxplot(data_by_mode, labels=modes, patch_artist=True)
        
        for patch in bp['boxes']:
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        
        ax.set_ylabel('Attribution Weight', fontsize=10)
        ax.set_title(title, fontsize=11, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='y')
        ax.set_ylim(0, 1)
        
        # Rotate x labels if needed
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    fig.suptitle('Attribution Distribution by Operational Mode\n(Melbourne Real Data)',
                fontsize=13, fontweight='bold', y=0.995)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  ✓ Saved {output_path}")

# ============================================
# MAIN EXECUTION
# ============================================

if __name__ == "__main__":
    print("="*60)
    print("X-VESTA ATTRIBUTION ANALYSIS - REAL MELBOURNE DATA")
    print("="*60)
    
    # Load scenarios
    print("\nLoading scenarios...")
    scenarios_df = pd.read_csv('xvesta_scenarios_melbourne.csv')
    print(f"  Loaded {len(scenarios_df)} scenarios")
    
    # Run attribution (use sample for speed, or all for final version)
    # For testing: use sample_size=5000
    # For paper: use sample_size=None (all data)
    results_df = analyze_attribution_patterns(
        scenarios_df, 
        sample_size=None
    )
    
    # Generate statistics
    stats = generate_statistics(results_df)
    
    # Save detailed results
    results_df.to_csv('attribution_results_melbourne.csv', index=False)
    print(f"\n✓ Saved detailed results to attribution_results_melbourne.csv")
    
    # Generate figures
    print("\nGenerating figures for paper...")
    create_figure_attribution_pie(results_df)
    create_figure_temporal_heatmap(results_df)
    create_figure_price_correlation(results_df)
    create_figure_mode_comparison(results_df)
    
    # Save statistics JSON for paper
    with open('attribution_statistics.json', 'w') as f:
        json.dump(stats, f, indent=2)
    print(f"✓ Saved statistics to attribution_statistics.json")
    
    print("\n" + "="*60)
    print("✓ ANALYSIS COMPLETE!")
    print("="*60)
    print("\nGenerated files:")
    print("  - attribution_results_melbourne.csv (detailed results)")
    print("  - attribution_statistics.json (statistics for paper)")
    print("  - fig_attribution_pie.png")
    print("  - fig_temporal_heatmap.png")
    print("  - fig_price_correlation.png")
    print("  - fig_mode_comparison.png")
    print("\nUse these figures in Section 5.4 of your paper!")