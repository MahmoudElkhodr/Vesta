"""
Legitimate Baseline Comparison for X-VESTA
Compares X-VESTA against realistic alternative explanation approaches
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Dict, List
import time

# ============================================
# SCENARIO DEFINITION
# ============================================

@dataclass
class TestScenario:
    """Representative V2G decision scenario"""
    sid: str
    vehicle_id: str
    timestamp: str
    action: str
    power_kw: float
    soc_pre: float
    soc_post: float
    price: float
    grid_stress: float
    temp_c: float
    mode: str
    
    # X-VESTA attribution (computed)
    w_econ: float
    w_auto: float
    w_grid: float
    w_batt: float

# Test scenarios spanning different decision types
scenarios = [
    TestScenario(
        sid="S1", vehicle_id="EV-001", timestamp="2023-10-15 08:00",
        action="CHARGE", power_kw=7.0, soc_pre=0.45, soc_post=0.59,
        price=0.25, grid_stress=0.35, temp_c=22.0, mode="BALANCED",
        w_econ=0.35, w_auto=0.50, w_grid=0.12, w_batt=0.03
    ),
    TestScenario(
        sid="S2", vehicle_id="EV-002", timestamp="2023-10-15 18:30",
        action="DISCHARGE", power_kw=7.0, soc_pre=0.85, soc_post=0.71,
        price=0.52, grid_stress=0.88, temp_c=28.0, mode="GRID_SUPPORT",
        w_econ=0.30, w_auto=0.15, w_grid=0.52, w_batt=0.03
    ),
    TestScenario(
        sid="S3", vehicle_id="EV-003", timestamp="2023-10-15 02:00",
        action="CHARGE", power_kw=7.0, soc_pre=0.30, soc_post=0.88,
        price=0.12, grid_stress=0.20, temp_c=15.0, mode="FULL_CHARGE",
        w_econ=0.18, w_auto=0.72, w_grid=0.08, w_batt=0.02
    ),
    TestScenario(
        sid="S4", vehicle_id="EV-004", timestamp="2023-10-15 14:00",
        action="PAUSE", power_kw=0.0, soc_pre=0.60, soc_post=0.60,
        price=0.48, grid_stress=0.42, temp_c=24.0, mode="MAX_SAVINGS",
        w_econ=0.85, w_auto=0.08, w_grid=0.05, w_batt=0.02
    ),
    TestScenario(
        sid="S5", vehicle_id="EV-EMERG", timestamp="2023-10-15 11:00",
        action="CHARGE", power_kw=7.0, soc_pre=0.40, soc_post=0.68,
        price=0.38, grid_stress=0.65, temp_c=26.0, mode="BALANCED",
        w_econ=0.15, w_auto=0.75, w_grid=0.08, w_batt=0.02
    ),
]

# ============================================
# BASELINE IMPLEMENTATIONS
# ============================================

class BaselineA_RawLogs:
    """Baseline A: Raw technical logs (no explanation)"""
    
    def generate(self, scenario: TestScenario) -> Dict[str, str]:
        driver_msg = (f"Action: {scenario.action}, Power: {scenario.power_kw}kW, "
                     f"SoC: {scenario.soc_pre:.0%}→{scenario.soc_post:.0%}")
        
        operator_msg = (f"[{scenario.sid}] {scenario.action} P={scenario.power_kw}kW "
                       f"Price=${scenario.price:.2f} Grid={scenario.grid_stress:.2f}")
        
        return {
            'driver': driver_msg,
            'operator': operator_msg,
            'method': 'Raw Logs'
        }

class BaselineB_StaticTemplates:
    """Baseline B: Simple static templates (no attribution)"""
    
    templates = {
        'CHARGE': "Charging at {power}kW to reach target charge level.",
        'DISCHARGE': "Supporting the grid by discharging at {power}kW.",
        'PAUSE': "Charging paused to optimize costs."
    }
    
    def generate(self, scenario: TestScenario) -> Dict[str, str]:
        template = self.templates.get(scenario.action, "Action: {action}")
        driver_msg = template.format(
            power=scenario.power_kw,
            action=scenario.action
        )
        
        operator_msg = f"[{scenario.sid}] {scenario.action} Mode={scenario.mode}"
        
        return {
            'driver': driver_msg,
            'operator': operator_msg,
            'method': 'Static Templates'
        }

class BaselineC_VerboseDump:
    """Baseline C: Verbose feature dump (all parameters, no interpretation)"""
    
    def generate(self, scenario: TestScenario) -> Dict[str, str]:
        driver_msg = (f"Action: {scenario.action} ({scenario.power_kw}kW). "
                     f"Price: ${scenario.price:.2f}/kWh, Grid stress: {scenario.grid_stress:.2f}, "
                     f"Temperature: {scenario.temp_c}°C, SoC: {scenario.soc_pre:.0%}→{scenario.soc_post:.0%}, "
                     f"Mode: {scenario.mode}")
        
        operator_msg = driver_msg  # Same for both
        
        return {
            'driver': driver_msg,
            'operator': operator_msg,
            'method': 'Verbose Dump'
        }

class BaselineD_SingleFactor:
    """Baseline D: Single dominant factor only (no nuance)"""
    
    def generate(self, scenario: TestScenario) -> Dict[str, str]:
        # Find dominant factor
        factors = {
            'price': scenario.w_econ,
            'user priority': scenario.w_auto,
            'grid support': scenario.w_grid,
            'battery health': scenario.w_batt
        }
        dominant = max(factors.items(), key=lambda x: x[1])[0]
        
        driver_msg = f"{scenario.action.capitalize()} due to {dominant}."
        operator_msg = f"[{scenario.sid}] {scenario.action} Factor={dominant}"
        
        return {
            'driver': driver_msg,
            'operator': operator_msg,
            'method': 'Single Factor'
        }

class XVESTAExplainer:
    """X-VESTA: Semantic attribution with stakeholder adaptation"""
    
    def generate(self, scenario: TestScenario) -> Dict[str, str]:
        # Driver message: natural language with dominant factor
        dominant_weight = max(scenario.w_econ, scenario.w_auto, 
                            scenario.w_grid, scenario.w_batt)
        
        if scenario.w_econ == dominant_weight:
            if scenario.action == "PAUSE":
                driver_msg = f"Charging paused due to high prices (${scenario.price:.2f}/kWh)."
            else:
                driver_msg = f"{scenario.action.capitalize()} at {scenario.power_kw:.0f}kW during favorable pricing (${scenario.price:.2f}/kWh)."
        elif scenario.w_auto == dominant_weight:
            driver_msg = f"{scenario.action.capitalize()} at {scenario.power_kw:.0f}kW to reach target charge ({scenario.soc_post:.0%})."
        elif scenario.w_grid == dominant_weight:
            driver_msg = f"{scenario.action.capitalize()} at {scenario.power_kw:.0f}kW to support grid during peak demand."
        else:
            driver_msg = f"{scenario.action.capitalize()} at {scenario.power_kw:.0f}kW with battery protection active."
        
        # Operator message: structured with full attribution
        operator_msg = (f"[{scenario.sid}] {scenario.action} P={scenario.power_kw}kW | "
                       f"ATTR: econ={scenario.w_econ:.2f}, auto={scenario.w_auto:.2f}, "
                       f"grid={scenario.w_grid:.2f}, batt={scenario.w_batt:.2f}")
        
        return {
            'driver': driver_msg,
            'operator': operator_msg,
            'method': 'X-VESTA'
        }

# ============================================
# EVALUATION METRICS
# ============================================

def compute_information_content(explanation: str, scenario: TestScenario) -> Dict[str, float]:
    """Measure what information each explanation provides"""
    
    metrics = {
        'mentions_action': 1.0 if scenario.action.lower() in explanation.lower() else 0.0,
        'mentions_price': 1.0 if any(word in explanation.lower() for word in ['price', 'cost', '$']) else 0.0,
        'mentions_soc': 1.0 if any(word in explanation.lower() for word in ['charge level', 'target', 'soc', '%']) else 0.0,
        'mentions_grid': 1.0 if any(word in explanation.lower() for word in ['grid', 'demand', 'peak']) else 0.0,
        'mentions_battery': 1.0 if any(word in explanation.lower() for word in ['battery', 'health', 'protection']) else 0.0,
        'has_quantification': 1.0 if any(char.isdigit() for char in explanation) else 0.0,
        'length_words': len(explanation.split()),
        'has_justification': 1.0 if any(word in explanation.lower() for word in ['due to', 'because', 'to', 'during']) else 0.0,
    }
    
    return metrics

def compute_stakeholder_appropriateness(driver_msg: str, operator_msg: str) -> Dict[str, float]:
    """Measure stakeholder-specific adaptation"""
    
    # Driver messages should be concise and natural language
    driver_score = 1.0 if len(driver_msg.split()) <= 15 else 0.5
    
    # Operator messages should be structured and complete
    operator_score = 1.0 if '[' in operator_msg and '=' in operator_msg else 0.0
    
    # Differentiation: messages should be different
    differentiation = 1.0 if driver_msg != operator_msg else 0.0
    
    return {
        'driver_appropriate': driver_score,
        'operator_appropriate': operator_score,
        'stakeholder_diff': differentiation
    }

def compute_latency(explainer_class, scenario: TestScenario, n_trials: int = 10000) -> float:
    """Measure computational overhead"""
    explainer = explainer_class()
    
    start = time.perf_counter()
    for _ in range(n_trials):
        _ = explainer.generate(scenario)
    end = time.perf_counter()
    
    return ((end - start) / n_trials) * 1000  # milliseconds

# ============================================
# RUN COMPARISON
# ============================================

def run_comparison():
    print("="*70)
    print("X-VESTA BASELINE COMPARISON ANALYSIS")
    print("="*70)
    
    explainers = [
        ('Raw Logs', BaselineA_RawLogs),
        ('Static Templates', BaselineB_StaticTemplates),
        ('Verbose Dump', BaselineC_VerboseDump),
        ('Single Factor', BaselineD_SingleFactor),
        ('X-VESTA', XVESTAExplainer)
    ]
    
    results = []
    
    # Generate explanations and compute metrics
    for name, ExplainerClass in explainers:
        explainer = ExplainerClass()
        
        scenario_results = []
        for scenario in scenarios:
            output = explainer.generate(scenario)
            
            # Information content
            driver_info = compute_information_content(output['driver'], scenario)
            
            # Stakeholder appropriateness
            stakeholder = compute_stakeholder_appropriateness(
                output['driver'], output['operator']
            )
            
            scenario_results.append({
                'method': name,
                'scenario': scenario.sid,
                'driver_msg': output['driver'],
                'operator_msg': output['operator'],
                **driver_info,
                **stakeholder
            })
        
        # Compute latency (using first scenario)
        latency = compute_latency(ExplainerClass, scenarios[0])
        
        for sr in scenario_results:
            sr['latency_ms'] = latency
        
        results.extend(scenario_results)
    
    df = pd.DataFrame(results)
    
    # Save detailed results
    df.to_csv('baseline_comparison_detailed.csv', index=False)
    print("\n✓ Saved detailed results to baseline_comparison_detailed.csv")
    
    # Aggregate metrics by method
    print("\n" + "="*70)
    print("AGGREGATE METRICS BY METHOD")
    print("="*70)
    
    agg = df.groupby('method').agg({
        'mentions_price': 'mean',
        'mentions_soc': 'mean',
        'mentions_grid': 'mean',
        'has_justification': 'mean',
        'length_words': 'mean',
        'driver_appropriate': 'mean',
        'operator_appropriate': 'mean',
        'stakeholder_diff': 'mean',
        'latency_ms': 'first'
    }).round(3)
    
    print(agg.to_string())
    
    # Create comparison table for paper
    print("\n" + "="*70)
    print("LATEX TABLE FOR PAPER")
    print("="*70)
    
    latex_metrics = agg[['mentions_price', 'mentions_soc', 'mentions_grid', 
                         'has_justification', 'stakeholder_diff', 'latency_ms']]
    
    print(latex_metrics.to_latex(float_format="%.2f"))
    
    # Create visualizations
    create_comparison_figures(df, agg)
    
    return df, agg

def create_comparison_figures(df, agg):
    """Generate comparison figures"""
    
    # Figure 1: Information Completeness Radar Chart
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Left: Information completeness
    ax1 = axes[0]
    methods = agg.index.tolist()
    metrics = ['mentions_price', 'mentions_soc', 'mentions_grid', 'has_justification']
    x = np.arange(len(methods))
    width = 0.2
    
    for i, metric in enumerate(metrics):
        values = [agg.loc[m, metric] for m in methods]
        ax1.bar(x + i*width, values, width, label=metric.replace('_', ' ').title())
    
    ax1.set_xlabel('Explanation Method', fontweight='bold')
    ax1.set_ylabel('Information Coverage (0-1)', fontweight='bold')
    ax1.set_title('Information Completeness Comparison', fontweight='bold')
    ax1.set_xticks(x + width * 1.5)
    ax1.set_xticklabels(methods, rotation=45, ha='right')
    ax1.legend(loc='upper left', fontsize=8)
    ax1.grid(axis='y', alpha=0.3)
    ax1.set_ylim(0, 1.1)
    
    # Right: Stakeholder adaptation
    ax2 = axes[1]
    driver_app = [agg.loc[m, 'driver_appropriate'] for m in methods]
    operator_app = [agg.loc[m, 'operator_appropriate'] for m in methods]
    stakeholder_diff = [agg.loc[m, 'stakeholder_diff'] for m in methods]
    
    x2 = np.arange(len(methods))
    width2 = 0.25
    
    ax2.bar(x2 - width2, driver_app, width2, label='Driver Appropriate', color='#ff7f0e')
    ax2.bar(x2, operator_app, width2, label='Operator Appropriate', color='#2ca02c')
    ax2.bar(x2 + width2, stakeholder_diff, width2, label='Differentiation', color='#1f77b4')
    
    ax2.set_xlabel('Explanation Method', fontweight='bold')
    ax2.set_ylabel('Appropriateness Score (0-1)', fontweight='bold')
    ax2.set_title('Stakeholder Adaptation Comparison', fontweight='bold')
    ax2.set_xticks(x2)
    ax2.set_xticklabels(methods, rotation=45, ha='right')
    ax2.legend(loc='upper left', fontsize=8)
    ax2.grid(axis='y', alpha=0.3)
    ax2.set_ylim(0, 1.1)
    
    plt.tight_layout()
    plt.savefig('fig_baseline_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("\n✓ Saved fig_baseline_comparison.png")
    
    # Figure 2: Example outputs
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.axis('off')
    
    # Select one scenario (S2 - grid support)
    scenario_df = df[df['scenario'] == 'S2']
    
    y_pos = 0.95
    for _, row in scenario_df.iterrows():
        # Method name
        ax.text(0.02, y_pos, row['method'], fontsize=11, fontweight='bold')
        y_pos -= 0.03
        
        # Driver message
        ax.text(0.02, y_pos, f"Driver: {row['driver_msg']}", 
               fontsize=9, style='italic', wrap=True)
        y_pos -= 0.03
        
        # Operator message
        ax.text(0.02, y_pos, f"Operator: {row['operator_msg']}", 
               fontsize=8, family='monospace')
        y_pos -= 0.05
        
        # Separator
        ax.plot([0, 1], [y_pos, y_pos], 'k-', linewidth=0.5, alpha=0.3)
        y_pos -= 0.03
    
    ax.set_title(')', 
                fontsize=12, fontweight='bold', pad=20)
    
    plt.tight_layout()
    plt.savefig('fig_baseline_examples.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Saved fig_baseline_examples.png")

# ============================================
# MAIN EXECUTION
# ============================================

if __name__ == "__main__":
    df, agg = run_comparison()
    
    print("\n" + "="*70)
    print("✓ COMPARISON COMPLETE")
    print("="*70)
    print("\nGenerated files:")
    print("  - baseline_comparison_detailed.csv")
    print("  - fig_baseline_comparison.png")
    print("  - fig_baseline_examples.png")
    print("\nUse these in Section 5.5 of your paper!")