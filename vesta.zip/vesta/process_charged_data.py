"""
CHARGED Dataset Processor for X-VESTA Validation
Extracts charging sessions from Melbourne data and creates decision scenarios
"""

import pandas as pd
import numpy as np
from datetime import datetime
from typing import List, Dict

# ============================================
# STEP 1: LOAD AND UNDERSTAND THE DATA
# ============================================

def load_charged_data(price_path: str, volume_path: str, weather_path: str):
    """Load the three CSV files"""
    print("Loading CHARGED Melbourne data...")
    
    # Load price data (time x chargers)
    price_df = pd.read_csv(price_path, parse_dates=['time'])
    price_df = price_df.set_index('time')
    
    # Load volume data (time x chargers)  
    volume_df = pd.read_csv(volume_path)
    volume_df['time'] = pd.to_datetime(volume_df.iloc[:, 0])
    volume_df = volume_df.set_index('time')
    
    # Load weather data (time x weather variables)
    weather_df = pd.read_csv(weather_path)
    weather_df.columns = weather_df.columns.str.strip()  # Clean column names
    weather_df['time'] = pd.to_datetime(weather_df.iloc[:, 0])
    weather_df = weather_df.set_index('time')
    
    print(f"  Price data: {price_df.shape[0]} hours x {price_df.shape[1]} chargers")
    print(f"  Volume data: {volume_df.shape[0]} hours x {volume_df.shape[1]} chargers")
    print(f"  Weather data: {weather_df.shape[0]} hours x {weather_df.shape[1]} variables")
    print(f"  Date range: {price_df.index.min()} to {price_df.index.max()}")
    
    return price_df, volume_df, weather_df

# ============================================
# STEP 2: EXTRACT CHARGING SESSIONS
# ============================================

def extract_charging_sessions(price_df: pd.DataFrame, 
                              volume_df: pd.DataFrame,
                              weather_df: pd.DataFrame,
                              min_energy_kwh: float = 5.0) -> List[Dict]:
    """
    Extract individual charging sessions from the time-series data.
    
    A "session" is any hour where a charger had non-zero volume.
    """
    print("\nExtracting charging sessions...")
    
    sessions = []
    
    # Get list of charger IDs (column names, excluding 'time' if present)
    charger_ids = [col for col in volume_df.columns if col not in ['time']]
    
    # Iterate through each timestamp
    for timestamp in volume_df.index:
        # Get weather for this hour
        try:
            temp = weather_df.loc[timestamp, 'temp']
            humidity = weather_df.loc[timestamp, 'humidity']
        except:
            temp = 20.0  # default if missing
            humidity = 60.0
        
        # Check each charger
        for charger_id in charger_ids:
            try:
                volume = volume_df.loc[timestamp, charger_id]
                price = price_df.loc[timestamp, charger_id]
                
                # Skip if no charging occurred or missing data
                if pd.isna(volume) or pd.isna(price) or volume < min_energy_kwh:
                    continue
                
                # Skip if price is zero (likely missing data)
                if price <= 0.0:
                    continue
                
                # Create session record
                session = {
                    'timestamp': timestamp,
                    'charger_id': charger_id,
                    'energy_kwh': float(volume),
                    'price_per_kwh': float(price),
                    'temperature_c': float(temp),
                    'humidity_pct': float(humidity),
                    'hour_of_day': timestamp.hour,
                    'day_of_week': timestamp.dayofweek,  # 0=Monday
                    'is_weekend': timestamp.dayofweek >= 5
                }
                
                sessions.append(session)
                
            except Exception as e:
                continue  # Skip problematic entries
    
    print(f"  Extracted {len(sessions)} charging sessions")
    return sessions

# ============================================
# STEP 3: CONVERT TO X-VESTA SCENARIOS
# ============================================

def sessions_to_xvesta_scenarios(sessions: List[Dict], 
                                 battery_capacity_kwh: float = 50.0) -> List[Dict]:
    """
    Convert charging sessions to X-VESTA decision scenarios.
    
    Assumptions:
    - Typical EV battery: 50 kWh
    - Sessions represent charging decisions
    - SoC estimated from energy delivered
    """
    print("\nConverting to X-VESTA scenarios...")
    
    scenarios = []
    
    for i, session in enumerate(sessions):
        # Estimate SoC trajectory
        # Assume charging started at some deficit, ended at target
        energy = session['energy_kwh']
        soc_delta = energy / battery_capacity_kwh
        
        # Estimate starting SoC (assume people don't charge from empty)
        # Random but realistic: 30-70% starting SoC
        soc_start = np.random.uniform(0.3, 0.7)
        soc_target = min(soc_start + soc_delta, 0.95)  # Don't exceed 95%
        
        # Infer operational mode from context
        hour = session['hour_of_day']
        price = session['price_per_kwh']
        
        if hour >= 22 or hour <= 6:  # Overnight
            mode = "FULL_CHARGE"
        elif price > 0.40:  # High price
            mode = "MAX_SAVINGS"
        else:
            mode = "BALANCED"
        
        # Estimate grid stress from price and time
        # High prices often correlate with high demand
        if price > 0.45 or (hour >= 17 and hour <= 20):
            grid_stress = 0.7 + np.random.uniform(0, 0.2)
        else:
            grid_stress = 0.2 + np.random.uniform(0, 0.3)
        
        # Create scenario
        scenario = {
            'sid': f"MEL-{i+1:05d}",
            'vehicle_id': f"EV-{session['charger_id']}",
            'timestamp': session['timestamp'],
            'mode': mode,
            'soc_start': round(soc_start, 2),
            'soc_target': round(soc_target, 2),
            'price': round(price, 2),
            'grid_stress': round(grid_stress, 2),
            'temp_c': round(session['temperature_c'], 1),
            'is_emergency': False,  # No emergency vehicles in public charging
            'action': 'CHARGE',  # All sessions were charging
            'power_kw': round(energy, 1),  # Assume charged over 1 hour
            'duration_h': 1.0,
            'final_soc': round(soc_target, 2),
            # Original session data for reference
            'original_energy_kwh': session['energy_kwh'],
            'hour_of_day': session['hour_of_day'],
            'is_weekend': session['is_weekend']
        }
        
        scenarios.append(scenario)
    
    print(f"  Created {len(scenarios)} X-VESTA scenarios")
    return scenarios

# ============================================
# STEP 4: BASIC STATISTICS
# ============================================

def print_scenario_statistics(scenarios: List[Dict]):
    """Print useful statistics about the scenarios"""
    df = pd.DataFrame(scenarios)
    
    print("\n" + "="*60)
    print("SCENARIO STATISTICS")
    print("="*60)
    
    print(f"\nTotal scenarios: {len(scenarios)}")
    print(f"Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    
    print("\nPrice distribution ($/kWh):")
    print(f"  Min:    ${df['price'].min():.2f}")
    print(f"  25th:   ${df['price'].quantile(0.25):.2f}")
    print(f"  Median: ${df['price'].median():.2f}")
    print(f"  75th:   ${df['price'].quantile(0.75):.2f}")
    print(f"  Max:    ${df['price'].max():.2f}")
    
    print("\nTemperature distribution (°C):")
    print(f"  Min:    {df['temp_c'].min():.1f}")
    print(f"  Median: {df['temp_c'].median():.1f}")
    print(f"  Max:    {df['temp_c'].max():.1f}")
    
    print("\nMode distribution:")
    print(df['mode'].value_counts())
    
    print("\nTemporal distribution:")
    print(f"  Weekday sessions: {(~df['is_weekend']).sum()}")
    print(f"  Weekend sessions: {df['is_weekend'].sum()}")
    
    print("\nHourly distribution (top 5 hours):")
    print(df['hour_of_day'].value_counts().head())

# ============================================
# STEP 5: SAVE RESULTS
# ============================================

def save_scenarios(scenarios: List[Dict], output_path: str = 'xvesta_scenarios_melbourne.csv'):
    """Save scenarios to CSV"""
    df = pd.DataFrame(scenarios)
    df.to_csv(output_path, index=False)
    print(f"\n✓ Saved {len(scenarios)} scenarios to {output_path}")

# ============================================
# MAIN EXECUTION
# ============================================

if __name__ == "__main__":
    # File paths - UPDATE THESE TO YOUR ACTUAL PATHS
    PRICE_FILE = "e_price.csv"
    VOLUME_FILE = "volume.csv"
    WEATHER_FILE = "weather.csv"
    
    print("="*60)
    print("CHARGED DATASET PROCESSOR FOR X-VESTA")
    print("="*60)
    
    try:
        # Step 1: Load data
        price_df, volume_df, weather_df = load_charged_data(
            PRICE_FILE, VOLUME_FILE, WEATHER_FILE
        )
        
        # Step 2: Extract sessions
        sessions = extract_charging_sessions(
            price_df, volume_df, weather_df,
            min_energy_kwh=5.0  # Only sessions with at least 5 kWh
        )
        
        if len(sessions) == 0:
            print("\n⚠️  No sessions found! Check your data files.")
            exit(1)
        
        # Step 3: Convert to X-VESTA format
        scenarios = sessions_to_xvesta_scenarios(sessions)
        
        # Step 4: Show statistics
        print_scenario_statistics(scenarios)
        
        # Step 5: Save
        save_scenarios(scenarios)
        
        print("\n" + "="*60)
        print("✓ PROCESSING COMPLETE!")
        print("="*60)
        print("\nNext steps:")
        print("1. Load xvesta_scenarios_melbourne.csv")
        print("2. Run your X-VESTA attribution code on these scenarios")
        print("3. Analyze attribution patterns")
        
    except FileNotFoundError as e:
        print(f"\n❌ Error: Could not find file: {e}")
        print("Please update the file paths at the top of this script.")
    except Exception as e:
        print(f"\n❌ Error processing data: {e}")
        import traceback
        traceback.print_exc()